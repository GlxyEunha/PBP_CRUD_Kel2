package com.example.crud;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import java.util.ArrayList;
import java.net.ContentHandler;
import java.util.List;

public class Database extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "ruangan.db";
    private static final int DATABASE_VERSION = 1;

    public Database(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "create table ruangan(nama text null, NoRuang text null, KapRuang int null, gedung text null);";
        Log.d("Data", "onCreate: " + sql);
        db.execSQL(sql);
        String sql1 = "create table gedung(nama text null);";
        Log.d("Data", "onCreate: " + sql1);
        db.execSQL(sql1);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db0, int db1, int db2) {

    }

    public void saveGedung(gedung gedung){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("namaGedung", gedung.getNamaGedung());

        db.insert("gedung",null, values);
        db.close();
    }

    public List<gedung> findAllGedung(){
        List<gedung> listGedung = new ArrayList<gedung>();
        String query = "SELECT * FROM "+ "gedung";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query,null);
        if(cursor.moveToFirst()){
            do{
                gedung gedung = new gedung();
                gedung.setNamaGedung(cursor.getString(0));

                listGedung.add(gedung);
            }while (cursor.moveToNext());
        }
        return listGedung;
    }

    public void delGedung(gedung gedung){
        SQLiteDatabase db=this.getWritableDatabase();
        db.delete("gedung", "nama"+"=?", new String[]{String.valueOf(gedung.getNamaGedung())});
        db.close();
    }

    public void saveRuangan(ruangan ruangan){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("namaRuangan", ruangan.getNamaRuangan());

        db.insert("ruangan",null, values);
        db.close();
    }

    public List<ruangan> findAllRuangan(){
        List<ruangan> listRuangan = new ArrayList<ruangan>();
        String query = "SELECT * FROM "+ "ruangan";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query,null);
        if(cursor.moveToFirst()){
            do{
                ruangan ruangan = new ruangan();
                ruangan.setNamaRuangan(cursor.getString(0));
                ruangan.setNoRuangan(cursor.getString(1));
                ruangan.setKapRuangan(Integer.valueOf(cursor.getString(2)));
                ruangan.setNamaGedung(cursor.getString(3));
                listRuangan.add(ruangan);
            }while (cursor.moveToNext());
        }
        return listRuangan;
    }

    public void delRuangan(ruangan ruangan){
        SQLiteDatabase db=this.getWritableDatabase();
        db.delete("ruangan", "NoRuang"+"=?", new String[]{String.valueOf(ruangan.getNoRuangan())});
        db.close();
    }
}

package com.example.crud;

import java.util.ArrayList;

public class gedung {

    private String namaGedung;
    private ArrayList<ruangan> ruangan;

    public gedung(){}

    public gedung(String namaGedung){
        this.namaGedung = namaGedung;
    }

    public String getNamaGedung(){
        return this.namaGedung;
    }

    public void setNamaGedung(String namaGedung){
        this.namaGedung = namaGedung;
    }

    public ArrayList<ruangan> getRuangan(ArrayList<ruangan> ruangan){
        return this.ruangan;
    }
}

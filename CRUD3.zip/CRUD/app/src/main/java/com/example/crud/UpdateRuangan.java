package com.example.crud;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateRuangan extends AppCompatActivity {
    protected Cursor cursor;
    Database database;
    Button btn_simpan;
    EditText nama, NoRuang, KapRuang, gedung;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_ruangan);
        database = new Database(this);
        nama = findViewById(R.id.nama);
        NoRuang = findViewById(R.id.NoRuang);
        KapRuang = findViewById(R.id.KapRuang);
        gedung = findViewById(R.id.gedung);
        btn_simpan = findViewById(R.id.btn_simpan);

        SQLiteDatabase db = database.getReadableDatabase();
        cursor = db.rawQuery("SELECT * FROM ruangan WHERE nama = '" +
                getIntent().getStringExtra("nama")+"'", null);
        cursor.moveToFirst();
        if (cursor.getCount() >0){
            cursor.moveToPosition(0);
            nama.setText(cursor.getString(0).toString());
            NoRuang.setText(cursor.getString(1).toString());
            KapRuang.setText(cursor.getString(2).toString());
            gedung.setText(cursor.getString(3).toString());
        }

        btn_simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db = database.getWritableDatabase();
                db.execSQL("update ruangan set nama = '" +
                        nama.getText().toString()+"', NoRuang = '" +
                        NoRuang.getText().toString() + "', KapRuang = '"+
                        KapRuang.getText().toString() + "', gedung = '"+
                        gedung.getText().toString() + "' where nama = '" +
                        getIntent().getStringExtra("nama")+"'");
                Toast.makeText(UpdateRuangan.this, "Data berhasil di simpan", Toast.LENGTH_SHORT).show();
                ListRuangan.lr.RefreshList1();
                finish();
            }
        });
    }
}
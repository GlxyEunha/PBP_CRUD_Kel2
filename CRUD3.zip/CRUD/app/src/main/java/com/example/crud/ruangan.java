package com.example.crud;
import java.util.ArrayList;

public class ruangan {
    private String namaRuangan;
    private String noRuangan;
    private int kapRuangan;
    private gedung gedung;
    private String namaGedung;

    public ruangan(){}

    public ruangan(String namaRuangan, String noRuangan, int kapRuangan, gedung namaGedung){
        this.namaRuangan = namaRuangan;
        this.noRuangan = noRuangan;
        this.kapRuangan = kapRuangan;
        this.gedung = gedung;
    }

    public String getNamaRuangan(){
        return this.namaRuangan;
    }

    public void setNamaRuangan(String namaRuangan){
        this.namaRuangan = namaRuangan;
    }

    public String getNoRuangan(){
        return this.noRuangan;
    }

    public void setNoRuangan(String noRuangan){
        this.noRuangan = noRuangan;
    }

    public int getKapRuangan(){
        return this.kapRuangan;
    }

    public void setKapRuangan(int kapRuangan){
        this.kapRuangan = kapRuangan;
    }

    public gedung getGedung(){
        return this.gedung;
    }

    public void setGedung(gedung gedung){
        this.gedung = gedung;
    }

    public String getNamaGedung(){
        return this.namaGedung;
    }

    public void setNamaGedung(String namaGedung){
        this.namaGedung = namaGedung;
    }
}
